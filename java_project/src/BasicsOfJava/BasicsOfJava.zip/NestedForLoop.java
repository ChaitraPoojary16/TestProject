package BasicsOfJava;

public class NestedForLoop {
	public static void main(String[] args) {
		for(int j=0;j<=5;j++) 
		{
			for(int i=0; i<=5; i++)
			{
				System.out.print(i);
			}
			System.out.println("");
		}
	}
}
