package BasicsOfJava;

public class ArithmaticProblems {

	public static void main(String[] args) {

//Area of a circle = pi*r*r
		int radius = 5;
		double pi = 3.14;
		double area = pi*radius*radius;
		System.out.println("the area of circle is "+area);
		System.out.println("the circumference of circle is "+(2*pi*radius));
		
		/* Assignments 
		 * write a pgm to calculate SI 
		 * area of a triagle 
		 * differnce btw integer types(short, int, long)
		 */
	}

}
