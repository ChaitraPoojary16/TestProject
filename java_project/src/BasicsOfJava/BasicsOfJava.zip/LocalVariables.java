package BasicsOfJava;

public class LocalVariables {
	public void show() {
		int x = 10;
		System.out.println("Inside show method, x = " + x);
	}
	public void display() {
		int y = 20;
		System.out.println("Inside display method, y = " + y);
		// trying to access variable 'x' - generates an ERROR
		// System.out.println("Inside display method, x = " + x);
	}
	public static void main(String args[]) {
		LocalVariables obj = new LocalVariables();
		obj.show();
		obj.display();
	}
}
