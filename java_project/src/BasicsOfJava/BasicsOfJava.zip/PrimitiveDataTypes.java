package BasicsOfJava;

public class PrimitiveDataTypes {
	
	byte i;
	short j;
	int k;
	long l;
	float m;
	double n;
	char ch;
	boolean p;
	
	public static void main(String[] args)
	{		
		PrimitiveDataTypes obj = new PrimitiveDataTypes();
		
		System.out.println("i = " + obj.i + ", j = " + obj.j + ", k = " + obj.k + ", l = " + obj.l);
		System.out.println("m = " + obj.m + ", n = " + obj.n);
		System.out.println("ch = " + obj.ch);
		System.out.println("p = " + obj.p);
		
	}
}