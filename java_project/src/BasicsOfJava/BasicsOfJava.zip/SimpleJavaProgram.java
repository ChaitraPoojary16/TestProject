package BasicsOfJava;

class SimpleJavaProgram {
	
	public static void main(String[] args)
	{
		// DATA Types.
		
	}
}
