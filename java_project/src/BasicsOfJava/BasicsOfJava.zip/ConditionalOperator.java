package BasicsOfJava;

public class ConditionalOperator {
	public static void main(String[] args) {

		int a = 10, b = 20, c;
		
		c = (a>b)? a : b;
		
		System.out.println("c = " + c);
	}
}
