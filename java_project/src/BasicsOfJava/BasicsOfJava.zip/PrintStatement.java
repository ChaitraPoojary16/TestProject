package BasicsOfJava;

public class PrintStatement {

	public static void main(String[] args) 
	{
		/*
		 * System.out.println("Welcome to Java Programming!");
		 * System.out.print("Hi there!"); System.out.println("Hi there again!");
		 * System.out.println("123566  %$^& 84533");
		 */
		
		int x=10; int y=20;
		System.out.println(x);System.out.println(y);
		System.out.println(x+y);
		System.out.println("chiru");
		System.out.println("guru");
		System.out.println("chiru"+"guru");
		System.out.println("the value of x="+(x+y));
		System.out.println("");
	
		/*
		 * System.out.println("Java is " + "object based language");
		 * System.out.println("the value is = "+20);
		 * System.out.println("the value is = "+(20+20));
		 * System.out.println((20+20)+"is the value");
		 */
		 
	}
	// System.out.println("Welcome to Java!"); cannot write here in class area
	// + is concatenation op6erator
}
