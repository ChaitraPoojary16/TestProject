package BasicsOfJava;

public class RelationalOperators {public static void main(String[] args) {

	boolean a;
	
	a = 10<5;
	System.out.println("10 < 5 is " + a);
	
	a = 10>5;
	System.out.println("10 > 5 is " + a);
	
	a = 10<=5;
	System.out.println("10 <= 5 is " + a);
	
	a = 10>=5;
	System.out.println("10 >= 5 is " + a);
	
	a = 10==5;
	System.out.println("10 == 5 is " + a);
	
	a = 10!=5;
	System.out.println("10 != 5 is " + a);
	}
}
