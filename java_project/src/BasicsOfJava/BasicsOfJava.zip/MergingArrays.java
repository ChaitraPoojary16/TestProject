package BasicsOfJava;

import java.util.Scanner;

public class MergingArrays {

	public static void main(String[] args) 
	{
		Scanner ref = new Scanner(System.in);
//first array
		System.out.println("Please enter the size of first array");
		int size1  = ref.nextInt();// take the size from user

		int[] rak = new int[size1];// create the array

		for(int i=0; i<size1; i++)// read the values from user into the array
		{
			System.out.println("enter the value for index "+i);
			rak[i] = ref.nextInt();
		}
		//print the array
		System.out.println("the contents of the array rak is \n");
		for(int i=0; i<rak.length;i++)
		{
			System.out.println(rak[i]);
		}
//second array
		System.out.println("Please enter the size of second array");
		int size2  = ref.nextInt();// take the size from user

		int[] chir = new int[size2];// create the array

		for(int i=0; i<size2; i++)// read the values from user into the array
		{
			System.out.println("enter the value for index "+i);
			chir[i] = ref.nextInt();
		}
		//print the array
		System.out.println("the contents of the array chir is \n");
		for(int i=0; i<chir.length;i++)
		{
			System.out.println(chir[i]);
		}

// merge two arrays
		int[] kj = new int[size1 + size2];
		for(int m=0; m<kj.length; m++)
		{
			if(m<rak.length)
			{
				kj[m] = rak[m];
			}
			else
			{
				kj[m] = chir[m-rak.length];
			}	
		}
		//print the array
		System.out.println("the contents of the merged array kj is \n");
		for(int i=0; i<kj.length;i++)
		{
			System.out.println(kj[i]);
		}
	}


}
