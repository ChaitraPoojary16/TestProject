package BasicsOfJava;

public class SyntaxSymanticError 
{
	
	public static void main(String[] args) {
		System.out.println("Hello world !!");
		int x=10;
		System.out.println(x);
		int main=10;
		System.out.println(main);
		int Main=20;
		System.out.println(Main);
	}
	
}
