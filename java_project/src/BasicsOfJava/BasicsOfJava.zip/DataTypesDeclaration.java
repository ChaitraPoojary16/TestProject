package BasicsOfJava;

public class DataTypesDeclaration {
	public static void main(String[] args) {		
		byte a =10;
		int empId = 1234;
		long length = 123;
		float f = 4.7333434f;
		double salary = 2000.534;
		char val = 'a';
		boolean isEmpty = true;
		
		System.out.println(a);
		System.out.println(empId);
		System.out.println(length);
		System.out.println(f);
		System.out.println(salary);
		System.out.println(val);
		System.out.println(isEmpty);		

		
		/*
		 * int x=10;//initialization System.out.println("value of x is "+x); x =
		 * 90;//re-initialization System.out.println("value of x is "+x);
		 * System.out.println();
		 * 
		 * int n1=10;int n2=20;int n3=30; System.out.println("n1 is "+n1);
		 * System.out.println("n2 is "+n2); System.out.println("n3 is "+n3);
		 * System.out.println(); n1=n2; n2=n3; System.out.println("n1 is "+n1);
		 * System.out.println("n2 is "+n2);
		 * 
		 * //final int a = 100;//cannot re-initialization System.out.println("a is "+a);
		 * //a=90;
		 */
	}

}
