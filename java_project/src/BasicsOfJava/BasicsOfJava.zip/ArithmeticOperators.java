package BasicsOfJava;

public class ArithmeticOperators {
	public static void main(String[] args) {

		int a = 10, b = 20, result;

		System.out.println("a = " + a + ", b = " + b);
		
		result = a + b;//30
		System.out.println("Addition : " + a + " + " + b + " = " + result);
		System.out.println("the sum of two numers = "+result);
		
		result = a - b;//-10
		System.out.println("Subtraction : " + a + " - " + b + " = " + result);
		
		result = a * b;//200
		System.out.println("Multiplucation : " + a + " * " + b + " = " + result);
		
		result = b / a;//2
		System.out.println("Division : " + b + " / " + a + " = " + result);
		
		int  x = 15, y = 10;
		result = x % y;//remainder 2
		System.out.println("Modulus : " + x + " % " + y + " = " + result);
		
		result = ++a;
		System.out.println("Pre-increment : ++a = " + result);
		
		result = b--;
		System.out.println("Post-decrement : b-- = " + result);
	}
}
