package BasicsOfJava;

public class LoopStatementsFor {
	
	public static void main(String[] args) 
	{
		//print numbers 0 to 5
		for(int i=0; i<=5; i++)
		{
			System.out.println(i);
		}
		System.out.println("");
		//print numbers 5 to 0
		for(int i=5; i>=0; i--)
		{
			System.out.println(i);
		}
	}
}
