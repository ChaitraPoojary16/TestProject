package BasicsOfJava;

public class ControlStatementsNestedIf 
{
	public static void main(String[] args) {
	
	boolean flag = false;
	if(flag)
	{
		System.out.println("inside parent if block");
		int x=90;
		if(x > 50)
		{
			System.out.println("inside nested if block");
		}
	}
	
	
	
	}
}
