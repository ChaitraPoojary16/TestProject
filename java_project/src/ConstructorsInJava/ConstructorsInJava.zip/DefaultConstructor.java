package ConstructorsInJava;

public class DefaultConstructor {
	
	double dali;
	int kp;
	String chir;
	
	public static void main(String[] args) {
			
		DefaultConstructor rakObj = new DefaultConstructor();
		System.out.println(rakObj.dali);
		System.out.println(rakObj.kp);
		System.out.println(rakObj.chir);
	}
}
