package ConstructorsInJava;

public class Controuctorsmany {
	String name;
	double weight;
	int age;
	Controuctorsmany()
	{
		System.out.println("inside no arg constructor");
	}
	Controuctorsmany(String name, int age)
	{
		System.out.println("inside 2 arg constructor");
		this.name = name;
		this.age = age;
	}
	Controuctorsmany(String name, int age, double weight)
	{
		System.out.println("inside 3 arg constructor");
		this.name = name;
		this.age = age;
		this.weight = weight;
	}
	public static void main(String[] args) {
		System.out.println("inside main method");
		Controuctorsmany obj = new Controuctorsmany();
		System.out.println(obj.name+ " "+obj.age);
		
		obj = new Controuctorsmany("Dhanu", 24);
		System.out.println(obj.name+ " "+obj.age);

		obj = new Controuctorsmany("kp", 31, 56.600);
		System.out.println(obj.name+ " "+obj.age + " "+ obj.weight);
	}
}
