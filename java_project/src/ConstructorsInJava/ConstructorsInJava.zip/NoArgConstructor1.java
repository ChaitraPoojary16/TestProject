65package ConstructorsInJava;

public class NoArgConstructor1 
{
	NoArgConstructor1()
	{
		System.out.println("inside no argument constructor");
	}
	public static void main(String[] args) 
	{
		NoArgConstructor1 obj =  new NoArgConstructor1();
	}
}
