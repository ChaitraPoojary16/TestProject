package ConstructorsInJava;

public class Constructors {
	String collegeName;
	
	Constructors(String s)
	{
		System.out.println("inside parameterized constructor");
		this.collegeName = s;
	}
	
	public static void main(String[] args) {
		
		Constructors obj = new Constructors("VTU");
		System.out.println("inside main method");
		System.out.println("instance varialble value is "+obj.collegeName);
	}
}
